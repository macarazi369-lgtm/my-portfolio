// ============================================================
//  EDIT YOUR CONTENT HERE — most changes happen in this file.
// ============================================================

export const site = {
  name: 'Macarazi',
  wordmark: 'MACARAZI',
  title: 'Web Developer & Website Designer',
  email: 'macarazi369@gmail.com',
  location: 'Nigeria (remote-friendly)',
  // Put your photo at public/images/macarazi-profile.jpg (same file name) to replace it.
  photo: '/images/macarazi-profile.jpg',
  photoAlt: 'Portrait of Macarazi, web developer and website designer',
  // Set show to false to hide the green availability badge in the hero.
  availability: { show: true, text: 'Available for freelance projects' },
  // Digits only with country code, e.g. '2348012345678'. Leave '' to hide the WhatsApp button.
  whatsappNumber: '',
}

// Social links: leave url as '' and the link is hidden automatically.
export const socials = [
  { label: 'GitHub', url: '' },
  { label: 'LinkedIn', url: '' },
  { label: 'X (Twitter)', url: '' },
  { label: 'Instagram', url: '' },
]

// Stats: only items with a non-empty value are shown. If none have a value, the whole strip is hidden.
// Only fill in numbers that are true, e.g. { label: 'Completed Projects', value: '12' }
export const stats = [
  { label: 'Completed Projects', value: '' },
  { label: 'Years of Experience', value: '' },
  { label: 'Client Satisfaction', value: '' },
  { label: 'Technologies Used', value: '' },
]

// Skills: add or delete lines freely.
export const skillGroups = [
  { title: 'Website Development', skills: ['HTML', 'CSS', 'JavaScript'] },
  { title: 'WordPress Development', skills: ['WordPress', 'Elementor', 'Responsive Website Design', 'Website Customization'] },
  { title: 'Design & User Experience', skills: ['Website Layout Design', 'Mobile-First Design', 'Website Visual Presentation', 'User-Friendly Interfaces'] },
  { title: 'Tools & Workflow', skills: ['Visual Studio Code', 'AI-assisted development tools'] },
]

// Projects.
//  - category: use one of the names below (or invent your own; filters are built automatically)
//  - image: '' shows a labelled placeholder. To use a screenshot, save it in public/images/projects/
//           and write e.g. '/images/projects/my-site.jpg'
//  - url: '' hides the "Live Preview" button
//  - caseStudy: delete it (or set to null) and the "View Case Study" button disappears
export const projects = [
  {
    id: 'sample-1',
    name: 'Sample Project One (replace me)',
    category: 'Business Websites',
    description: 'Sample entry. Replace this with a short, honest description of a real website you built.',
    tech: ['HTML', 'CSS', 'JavaScript'],
    image: '',
    url: '',
    caseStudy: {
      overview: '[Describe what the website is and who it is for.]',
      objective: '[What did the client or the design need to achieve?]',
      contribution: '[What exactly did you do on this project?]',
      decisions: ['[A key design decision]', '[Another key design decision]'],
      screenshots: [],
    },
  },
  {
    id: 'sample-2',
    name: 'Sample Project Two (replace me)',
    category: 'WordPress / Elementor',
    description: 'Sample entry. Replace with your real WordPress or Elementor project.',
    tech: ['WordPress', 'Elementor'],
    image: '',
    url: '',
    caseStudy: null,
  },
  {
    id: 'sample-3',
    name: 'Sample Project Three (replace me)',
    category: 'Landing Pages',
    description: 'Sample entry. Replace with your real landing page project.',
    tech: ['HTML', 'CSS', 'JavaScript'],
    image: '',
    url: '',
    caseStudy: null,
  },
]

// Order in which filter buttons appear (only categories that have projects are shown).
export const categoryOrder = [
  'Business Websites',
  'WordPress / Elementor',
  'E-commerce',
  'Landing Pages',
  'Web Applications',
]

// Testimonials: leave this empty ([]) and the section is hidden.
// Only add REAL feedback from real clients, with their permission.
// Example: { quote: '...', name: 'Client Name', role: 'Business Owner' }
export const testimonials = []

export const services = [
  { icon: 'Globe', title: 'Business Website Design', type: 'Business Website', text: 'Professional websites that present your business clearly and help customers find and trust you.' },
  { icon: 'LayoutTemplate', title: 'WordPress & Elementor Development', type: 'WordPress / Elementor Website', text: 'Easy-to-manage WordPress sites built with Elementor and customised to fit your brand.' },
  { icon: 'ShoppingCart', title: 'E-commerce Website Design', type: 'E-commerce Website', text: 'Clean online store layouts that make your products easy to browse.' },
  { icon: 'Rocket', title: 'Landing Page Development', type: 'Landing Page', text: 'Focused single pages built around one clear goal, such as getting enquiries.' },
  { icon: 'RefreshCw', title: 'Website Redesign', type: 'Website Redesign', text: 'A fresh look and clearer structure for a website that feels outdated.' },
  { icon: 'Smartphone', title: 'Responsive Website Optimization', type: 'Responsive Optimization', text: 'Making an existing site look and work properly on phones, tablets and desktops.' },
]

export const projectTypes = [
  'Business Website',
  'WordPress / Elementor Website',
  'E-commerce Website',
  'Landing Page',
  'Website Redesign',
  'Responsive Optimization',
  'Web Application',
  'Other',
]

export const process = [
  { title: 'Discovery', text: "Understand the client's business, goals, and requirements." },
  { title: 'Planning', text: 'Establish the page structure, content, and design direction.' },
  { title: 'Design & Development', text: 'Build the website and optimize the layout for different devices.' },
  { title: 'Review & Delivery', text: 'Test the website, collect feedback, make agreed revisions, and prepare the finished project for launch.' },
]

export const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Expertise', href: '#expertise' },
  { label: 'Projects', href: '#projects' },
  { label: 'Contact', href: '#contact' },
]
