import { useState } from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import About from './components/About'
import Expertise from './components/Expertise'
import Projects from './components/Projects'
import Services from './components/Services'
import Process from './components/Process'
import Testimonials from './components/Testimonials'
import Contact from './components/Contact'
import Footer from './components/Footer'
import useReveal from './hooks/useReveal'
import useActiveSection from './hooks/useActiveSection'

const sectionIds = ['home', 'about', 'expertise', 'projects', 'contact']

export default function App() {
  const [prefill, setPrefill] = useState(null)
  const active = useActiveSection(sectionIds)
  useReveal()

  return (
    <>
      <a href="#main" className="skip">Skip to content</a>
      <Navbar active={active} />
      <main id="main">
        <Hero />
        <About />
        <Expertise />
        <Projects />
        <Services onSelect={(type) => setPrefill({ type, k: Date.now() })} />
        <Process />
        <Testimonials />
        <Contact prefill={prefill} />
      </main>
      <Footer />
    </>
  )
}
