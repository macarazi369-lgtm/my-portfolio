import { ArrowUpRight } from 'lucide-react'

function Placeholder() {
  return (
    <div className="thumb thumb--placeholder" role="img" aria-label="Placeholder thumbnail. Replace with a real screenshot.">
      <div className="thumb__bar"><i /><i /><i /></div>
      <span>Sample thumbnail<br />Add your screenshot</span>
    </div>
  )
}

export default function ProjectCard({ project, onOpen }) {
  const { name, category, description, tech, image, url, caseStudy } = project
  return (
    <article className="card project">
      {image ? (
        <img className="thumb" src={image} alt={`Screenshot of ${name}`} width="800" height="500" loading="lazy" decoding="async" />
      ) : (
        <Placeholder />
      )}
      <div className="project__body">
        <p className="project__cat">{category}</p>
        <h3>{name}</h3>
        <p>{description}</p>
        {tech?.length > 0 && (
          <ul className="tags" aria-label="Technologies used">
            {tech.map((t) => <li key={t}>{t}</li>)}
          </ul>
        )}
        <div className="project__actions">
          {url && (
            <a className="btn btn--primary btn--sm" href={url} target="_blank" rel="noopener noreferrer">
              Live Preview <ArrowUpRight size={16} aria-hidden="true" />
            </a>
          )}
          {caseStudy && (
            <button className="btn btn--ghost btn--sm" onClick={() => onOpen(project)}>
              View Case Study
            </button>
          )}
        </div>
      </div>
    </article>
  )
}
