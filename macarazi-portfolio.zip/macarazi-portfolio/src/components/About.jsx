import SectionHeading from './SectionHeading'
import { stats } from '../data/siteConfig'

const focus = ['Website design', 'Responsive layouts', 'User experience', 'Business-focused web solutions']

export default function About() {
  const shown = stats.filter((s) => String(s.value).trim() !== '')
  return (
    <section id="about" className="section">
      <div className="container">
        <div className="about__grid">
          <SectionHeading label="ABOUT ME" title="Building Digital Experiences With Purpose." />
          <div className="about__body reveal">
            <p>
              I create websites designed to help businesses establish an online presence, present their
              services professionally, and connect with potential customers.
            </p>
            <p>
              My work centres on clean website design, responsive layouts that feel right on any screen,
              and a user experience that makes it easy for visitors to understand what a business offers
              and get in touch.
            </p>
            <p>
              Every project starts with the business and its goals, so the finished website is not just
              good-looking, but genuinely useful.
            </p>
            <ul className="chips" aria-label="Focus areas">
              {focus.map((f) => <li key={f}>{f}</li>)}
            </ul>
          </div>
        </div>

        {shown.length > 0 && (
          <dl className="stats reveal">
            {shown.map((s) => (
              <div key={s.label} className="stat">
                <dd>{s.value}</dd>
                <dt>{s.label}</dt>
              </div>
            ))}
          </dl>
        )}
      </div>
    </section>
  )
}
