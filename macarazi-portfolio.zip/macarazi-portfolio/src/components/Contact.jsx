import { useEffect, useState } from 'react'
import { Mail, MapPin, Send, CheckCircle2, AlertCircle, MessageCircle } from 'lucide-react'
import SectionHeading from './SectionHeading'
import { site, projectTypes } from '../data/siteConfig'

const ENDPOINT = import.meta.env.VITE_FORM_ENDPOINT
const empty = { name: '', email: '', type: '', budget: '', message: '', website: '' }

export default function Contact({ prefill }) {
  const [values, setValues] = useState(empty)
  const [errors, setErrors] = useState({})
  const [status, setStatus] = useState('idle') // idle | sending | success | error | unconfigured

  useEffect(() => {
    if (prefill?.type) setValues((v) => ({ ...v, type: prefill.type }))
  }, [prefill])

  const set = (k) => (e) => {
    setValues((v) => ({ ...v, [k]: e.target.value }))
    setErrors((er) => ({ ...er, [k]: undefined }))
  }

  const validate = () => {
    const er = {}
    if (values.name.trim().length < 2) er.name = 'Please enter your full name.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) er.email = 'Please enter a valid email address.'
    if (!values.type) er.type = 'Please choose a project type.'
    if (values.message.trim().length < 10) er.message = 'Please describe your project (at least 10 characters).'
    return er
  }

  const mailtoHref = () => {
    const body = `Name: ${values.name}\nEmail: ${values.email}\nProject type: ${values.type}\nBudget: ${values.budget || 'Not specified'}\n\n${values.message}`
    return `mailto:${site.email}?subject=${encodeURIComponent('Website project enquiry')}&body=${encodeURIComponent(body)}`
  }

  const onSubmit = async (e) => {
    e.preventDefault()
    if (values.website) return // honeypot: bots fill this hidden field
    const er = validate()
    setErrors(er)
    if (Object.keys(er).length) return

    if (!ENDPOINT) {
      setStatus('unconfigured') // be honest: nothing is sent
      return
    }
    setStatus('sending')
    try {
      const res = await fetch(ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          name: values.name, email: values.email, projectType: values.type,
          budget: values.budget, message: values.message,
        }),
      })
      if (!res.ok) throw new Error('Request failed')
      setStatus('success')
      setValues(empty)
    } catch {
      setStatus('error')
    }
  }

  const wa = site.whatsappNumber.replace(/\D/g, '')
  const field = (id, label, input, optional) => (
    <div className="field">
      <label htmlFor={id}>{label}{optional && <span className="optional"> (optional)</span>}</label>
      {input}
      {errors[id === 'type' ? 'type' : id] && <p className="field__error" id={`${id}-err`} role="alert">{errors[id]}</p>}
    </div>
  )

  return (
    <section id="contact" className="section section--alt">
      <div className="container contact__grid">
        <div>
          <SectionHeading
            label="LET'S CONNECT"
            title="Let's Build Something Exceptional."
            text="Have a website idea or a business that needs a stronger online presence? Tell me about your project, and let's discuss how I can help."
          />
          <ul className="contact__info reveal">
            <li><Mail size={20} aria-hidden="true" /><div><span>Email</span><a className="email" href={`mailto:${site.email}`}>{site.email}</a></div></li>
            <li><MapPin size={20} aria-hidden="true" /><div><span>Location</span><p>{site.location}</p></div></li>
          </ul>
          {wa && (
            <a className="btn btn--ghost reveal" href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer">
              <MessageCircle size={18} aria-hidden="true" /> Chat on WhatsApp
            </a>
          )}
        </div>

        <form className="card form reveal" onSubmit={onSubmit} noValidate>
          {status === 'success' ? (
            <div className="notice notice--ok" role="status">
              <CheckCircle2 size={22} aria-hidden="true" />
              <div>
                <strong>Message sent.</strong>
                <p>Thank you for reaching out. I'll reply to your email as soon as I can.</p>
                <button type="button" className="link" onClick={() => setStatus('idle')}>Send another message</button>
              </div>
            </div>
          ) : (
            <>
              {field('name', 'Full Name', <input id="name" name="name" autoComplete="name" value={values.name} onChange={set('name')} aria-invalid={!!errors.name} aria-describedby={errors.name ? 'name-err' : undefined} />)}
              {field('email', 'Email Address', <input id="email" name="email" type="email" autoComplete="email" value={values.email} onChange={set('email')} aria-invalid={!!errors.email} aria-describedby={errors.email ? 'email-err' : undefined} />)}
              {field('type', 'Project Type',
                <select id="type" name="type" value={values.type} onChange={set('type')} aria-invalid={!!errors.type} aria-describedby={errors.type ? 'type-err' : undefined}>
                  <option value="">Select a project type</option>
                  {projectTypes.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              )}
              {field('budget', 'Project Budget', <input id="budget" name="budget" placeholder="e.g. ₦150,000 or $300" value={values.budget} onChange={set('budget')} />, true)}
              {field('message', 'Project Description', <textarea id="message" name="message" rows="5" value={values.message} onChange={set('message')} aria-invalid={!!errors.message} aria-describedby={errors.message ? 'message-err' : undefined} />)}

              {/* Honeypot field: hidden from people, filled by spam bots */}
              <div className="hp" aria-hidden="true">
                <label>Website<input tabIndex={-1} autoComplete="off" value={values.website} onChange={set('website')} /></label>
              </div>

              <button className="btn btn--primary" type="submit" disabled={status === 'sending'}>
                {status === 'sending' ? 'Sending…' : <>Send Message <Send size={16} aria-hidden="true" /></>}
              </button>

              {status === 'error' && (
                <div className="notice notice--err" role="alert">
                  <AlertCircle size={20} aria-hidden="true" />
                  <p>Something went wrong and your message was not sent. Please try again, or email me at <a href={`mailto:${site.email}`}>{site.email}</a>.</p>
                </div>
              )}
              {status === 'unconfigured' && (
                <div className="notice notice--err" role="alert">
                  <AlertCircle size={20} aria-hidden="true" />
                  <p>This form isn't connected to an email service yet, so nothing was sent. <a href={mailtoHref()}>Click here to send it from your email app</a> instead.</p>
                </div>
              )}
            </>
          )}
        </form>
      </div>
    </section>
  )
}
