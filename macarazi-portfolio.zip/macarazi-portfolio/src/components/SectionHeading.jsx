export default function SectionHeading({ label, title, text, center }) {
  return (
    <div className={`section-head reveal ${center ? 'section-head--center' : ''}`}>
      <p className="eyebrow">{label}</p>
      <h2>{title}</h2>
      {text && <p className="section-head__text">{text}</p>}
    </div>
  )
}
