import { useMemo, useState, useCallback } from 'react'
import SectionHeading from './SectionHeading'
import ProjectCard from './ProjectCard'
import ProjectModal from './ProjectModal'
import { projects, categoryOrder } from '../data/siteConfig'

const ALL = 'All Projects'

export default function Projects() {
  const [filter, setFilter] = useState(ALL)
  const [open, setOpen] = useState(null)
  const close = useCallback(() => setOpen(null), [])

  const categories = useMemo(() => {
    const present = [...new Set(projects.map((p) => p.category))]
    const ordered = categoryOrder.filter((c) => present.includes(c))
    const extra = present.filter((c) => !categoryOrder.includes(c))
    return [ALL, ...ordered, ...extra]
  }, [])

  const visible = filter === ALL ? projects : projects.filter((p) => p.category === filter)

  return (
    <section id="projects" className="section">
      <div className="container">
        <SectionHeading
          label="PORTFOLIO"
          title="Selected Projects I've Built."
          text="A collection of website projects showcasing my approach to design, functionality, and user experience."
        />
        {categories.length > 2 && (
          <div className="filters reveal" role="group" aria-label="Filter projects">
            {categories.map((c) => (
              <button key={c} className={`filter ${filter === c ? 'is-active' : ''}`} aria-pressed={filter === c} onClick={() => setFilter(c)}>
                {c}
              </button>
            ))}
          </div>
        )}
        <div className="project-grid">
          {visible.map((p) => <ProjectCard key={p.id} project={p} onOpen={setOpen} />)}
        </div>
      </div>
      {open && <ProjectModal project={open} onClose={close} />}
    </section>
  )
}
