import { useEffect, useRef } from 'react'
import { X, ArrowUpRight } from 'lucide-react'

export default function ProjectModal({ project, onClose }) {
  const closeRef = useRef(null)
  const cs = project.caseStudy

  useEffect(() => {
    const prev = document.activeElement
    closeRef.current?.focus()
    document.body.style.overflow = 'hidden'
    const onKey = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
      prev?.focus?.()
    }
  }, [onClose])

  const Block = ({ title, children }) => (
    <section className="cs__block">
      <h4>{title}</h4>
      {children}
    </section>
  )

  return (
    <div className="modal" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal__panel" role="dialog" aria-modal="true" aria-labelledby="cs-title">
        <button ref={closeRef} className="modal__close" onClick={onClose} aria-label="Close case study">
          <X size={22} />
        </button>
        <p className="project__cat">{project.category}</p>
        <h3 id="cs-title">{project.name}</h3>

        {cs.overview && <Block title="Project overview"><p>{cs.overview}</p></Block>}
        {cs.objective && <Block title="Objective"><p>{cs.objective}</p></Block>}
        {cs.contribution && <Block title="My contribution"><p>{cs.contribution}</p></Block>}
        {project.tech?.length > 0 && (
          <Block title="Tools & technologies">
            <ul className="tags">{project.tech.map((t) => <li key={t}>{t}</li>)}</ul>
          </Block>
        )}
        {cs.decisions?.length > 0 && (
          <Block title="Key design decisions">
            <ul className="bullets">{cs.decisions.map((d) => <li key={d}>{d}</li>)}</ul>
          </Block>
        )}
        {cs.screenshots?.length > 0 && (
          <Block title="Screenshots">
            <div className="cs__shots">
              {cs.screenshots.map((s) => <img key={s} src={s} alt={`${project.name} screenshot`} loading="lazy" />)}
            </div>
          </Block>
        )}
        {project.url && (
          <a className="btn btn--primary" href={project.url} target="_blank" rel="noopener noreferrer">
            Visit live website <ArrowUpRight size={16} aria-hidden="true" />
          </a>
        )}
      </div>
    </div>
  )
}
