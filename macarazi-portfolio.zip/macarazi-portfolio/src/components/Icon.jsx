import { Globe, LayoutTemplate, ShoppingCart, Rocket, RefreshCw, Smartphone } from 'lucide-react'

const map = { Globe, LayoutTemplate, ShoppingCart, Rocket, RefreshCw, Smartphone }

export default function Icon({ name, ...props }) {
  const C = map[name] || Globe
  return <C aria-hidden="true" {...props} />
}
