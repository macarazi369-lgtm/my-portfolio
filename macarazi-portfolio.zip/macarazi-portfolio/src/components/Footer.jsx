import { site, socials, navLinks } from '../data/siteConfig'

export default function Footer() {
  const links = socials.filter((s) => s.url)
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div>
          <a href="#home" className="wordmark">{site.wordmark}<span className="dot">.</span></a>
          <p className="footer__desc">Modern, responsive websites for businesses and individuals.</p>
        </div>
        <nav aria-label="Footer">
          {navLinks.map((l) => <a key={l.href} href={l.href}>{l.label}</a>)}
        </nav>
        <div className="footer__contact">
          <a href={`mailto:${site.email}`}>{site.email}</a>
          {links.map((s) => <a key={s.label} href={s.url} target="_blank" rel="noopener noreferrer">{s.label}</a>)}
        </div>
      </div>
      <div className="container footer__bar">
        © {new Date().getFullYear()} {site.name}. All rights reserved.
      </div>
    </footer>
  )
}
