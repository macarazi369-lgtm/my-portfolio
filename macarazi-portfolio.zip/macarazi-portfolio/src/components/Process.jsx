import SectionHeading from './SectionHeading'
import { process } from '../data/siteConfig'

export default function Process() {
  return (
    <section id="process" className="section">
      <div className="container">
        <SectionHeading label="MY WORK PROCESS" title="How We Can Work Together." />
        <ol className="steps">
          {process.map((s, i) => (
            <li key={s.title} className="step reveal">
              <span className="step__num">{String(i + 1).padStart(2, '0')}</span>
              <h3>{s.title}</h3>
              <p>{s.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
