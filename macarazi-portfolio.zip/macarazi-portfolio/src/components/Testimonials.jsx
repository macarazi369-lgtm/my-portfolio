import SectionHeading from './SectionHeading'
import { testimonials } from '../data/siteConfig'

// Renders nothing until you add real testimonials in src/data/siteConfig.js
export default function Testimonials() {
  if (!testimonials.length) return null
  return (
    <section id="testimonials" className="section section--alt">
      <div className="container">
        <SectionHeading label="CLIENT FEEDBACK" title="What People Say About Working With Me." />
        <div className="testimonial-grid">
          {testimonials.map((t) => (
            <figure key={t.name} className="card testimonial reveal">
              <blockquote>“{t.quote}”</blockquote>
              <figcaption><strong>{t.name}</strong>{t.role && <span>{t.role}</span>}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
