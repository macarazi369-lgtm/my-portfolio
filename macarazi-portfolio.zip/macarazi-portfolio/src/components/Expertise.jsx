import { useState } from 'react'
import SectionHeading from './SectionHeading'
import { skillGroups } from '../data/siteConfig'

export default function Expertise() {
  const [filter, setFilter] = useState('All Skills')
  const tabs = ['All Skills', ...skillGroups.map((g) => g.title)]
  const visible = filter === 'All Skills' ? skillGroups : skillGroups.filter((g) => g.title === filter)

  return (
    <section id="expertise" className="section section--alt">
      <div className="container">
        <SectionHeading label="MY EXPERTISE" title="My Technical & Creative Skills." />
        <div className="filters reveal" role="group" aria-label="Filter skills">
          {tabs.map((t) => (
            <button key={t} className={`filter ${filter === t ? 'is-active' : ''}`} aria-pressed={filter === t} onClick={() => setFilter(t)}>
              {t}
            </button>
          ))}
        </div>
        <div className="skill-grid">
          {visible.map((g) => (
            <article key={g.title} className="card skill-card pop">
              <h3>{g.title}</h3>
              <ul>
                {g.skills.map((s) => <li key={s}>{s}</li>)}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
