import { ArrowRight } from 'lucide-react'
import { site } from '../data/siteConfig'

export default function Hero() {
  return (
    <section id="home" className="hero">
      <div className="container hero__grid">
        <div className="hero__text">
          {site.availability.show && (
            <p className="badge">
              <span className="badge__dot" aria-hidden="true" />
              {site.availability.text}
            </p>
          )}
          <h1>
            I Build Modern Websites That <span className="accent">Help Businesses Grow.</span>
          </h1>
          <p className="lead">
            I'm Macarazi, a web developer and website designer focused on creating modern,
            responsive, and user-friendly digital experiences for businesses and individuals.
          </p>
          <div className="hero__actions">
            <a href="#projects" className="btn btn--primary">
              Explore My Work <ArrowRight size={18} aria-hidden="true" />
            </a>
            <a href="#contact" className="btn btn--ghost">Let's Work Together</a>
          </div>
        </div>

        <div className="hero__visual">
          <div className="portrait">
            <img
              src={site.photo}
              alt={site.photoAlt}
              width="900"
              height="1125"
              fetchpriority="high"
              decoding="async"
            />
          </div>
          <div className="portrait__tag">
            <strong>{site.name}</strong>
            <span>{site.title}</span>
          </div>
        </div>
      </div>
    </section>
  )
}
