import SectionHeading from './SectionHeading'
import Icon from './Icon'
import { services } from '../data/siteConfig'

export default function Services({ onSelect }) {
  return (
    <section id="services" className="section section--alt">
      <div className="container">
        <SectionHeading label="WHAT I DO" title="Digital Solutions for Growing Businesses." />
        <div className="service-grid">
          {services.map((s) => (
            <article key={s.title} className="card service reveal">
              <span className="service__icon"><Icon name={s.icon} size={24} /></span>
              <h3>{s.title}</h3>
              <p>{s.text}</p>
              <a href="#contact" className="link" onClick={() => onSelect(s.type)}>
                Ask about this service →
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
