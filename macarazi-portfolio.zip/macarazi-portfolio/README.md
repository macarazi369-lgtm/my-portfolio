# Macarazi — Web Developer Portfolio

A dark, responsive portfolio built with **React + Vite** (plain CSS, Lucide icons, no backend).
Design inspired by the section structure and layout approach of timothyiloba.com, with original content and code.

## 1. What's in this folder

```
macarazi-portfolio/
├── index.html                 page title, SEO tags, fonts
├── package.json               project list of dependencies + commands
├── vite.config.js
├── .env.example               where the contact-form link goes (see section 8)
├── public/
│   ├── favicon.svg
│   └── images/
│       ├── macarazi-profile.jpg   <- YOUR PHOTO
│       └── projects/              <- put project screenshots here
└── src/
    ├── main.jsx, App.jsx
    ├── index.css              all styling (colours at the very top)
    ├── data/siteConfig.js     ALL your content: projects, skills, stats, links
    ├── hooks/                 scroll animations / active menu link
    └── components/            one file per section (Hero, About, Projects ...)
```

## 2. Which folder to open in VS Code
Open the **`macarazi-portfolio`** folder itself (File → Open Folder). You should see `package.json` directly inside it.

## 3. One-time requirement
Install **Node.js (LTS version)** from https://nodejs.org if you don't have it. Check with `node -v` in the terminal.

## 4. Install and run
In VS Code open the terminal (Terminal → New Terminal) and run, one at a time:

```
npm install
npm run dev
```

## 5. Open it in your browser
Go to **http://localhost:5173** (the terminal prints the exact address). Edits you save appear instantly. Stop the server with `Ctrl + C`.

## 6. Replace your profile picture
Save your new photo as `public/images/macarazi-profile.jpg` (same name, replacing the old file). A portrait with the face in the upper-middle and a 4:5 shape (e.g. 900 × 1125 px) looks best. Keep it under ~150 KB for fast loading. Alt text is in `src/data/siteConfig.js` (`photoAlt`).

## 7. Add a new project
1. Save a screenshot (about 1600 × 1000 px, `.jpg` or `.webp`) in `public/images/projects/`, e.g. `my-shop.jpg`.
2. Open `src/data/siteConfig.js`, find `export const projects`, and copy one block, adding a comma after it:

```js
{
  id: 'my-shop',                       // unique, no spaces
  name: 'My Shop',
  category: 'E-commerce',              // filter buttons are created automatically
  description: 'One or two honest sentences.',
  tech: ['WordPress', 'Elementor'],
  image: '/images/projects/my-shop.jpg',
  url: 'https://the-real-website.com', // '' hides the Live Preview button
  caseStudy: null,                     // or fill in like the first sample
},
```
Delete the three "sample" projects once you have real ones.

## 8. Change text, colours, email
- **Email, name, location, availability badge, WhatsApp, photo path:** `site` at the top of `src/data/siteConfig.js`.
- **WhatsApp button:** put your number in `whatsappNumber` (digits only, with country code, e.g. `'2348012345678'`). Empty = hidden.
- **Social links:** fill in the `url` of the ones you have; empty ones are hidden.
- **Stats:** type real numbers into `stats`. Empty ones are hidden; if all are empty the strip disappears.
- **Skills / services / process steps:** edit or delete lines in the same file.
- **Testimonials:** add real ones to `testimonials` (the section stays hidden while it's empty).
- **Headings and paragraphs:** open the matching file in `src/components/` (e.g. `Hero.jsx`, `About.jsx`).
- **Colours:** the `:root { ... }` block at the top of `src/index.css`. `--accent` is the main colour.

### Make the contact form really send emails
The form never claims a message was sent unless a service accepted it. To connect it:
1. Create a free form at https://formspree.io (use `macarazi369@gmail.com`) and copy its URL (looks like `https://formspree.io/f/abcd1234`).
2. Copy `.env.example` to a new file named `.env` and paste the URL after `VITE_FORM_ENDPOINT=`.
3. Stop and restart `npm run dev`.
Until then, the form shows a clear "not connected" notice with a button that opens the visitor's email app with the message filled in.

## 9. Troubleshooting
| Problem | Fix |
|---|---|
| `npm is not recognized` | Node.js isn't installed (or restart VS Code after installing). |
| `npm install` errors / stuck | Check your internet, delete the `node_modules` folder and `package-lock.json`, run `npm install` again. |
| Port 5173 already in use | Close the other terminal running it, or open the address the terminal shows. |
| Blank white page | Press F12 → Console and read the red error; it usually names the file and line you last edited (often a missing comma or quote in `siteConfig.js`). |
| Image not showing | Check the file name and extension match exactly (case-sensitive) and the path starts with `/images/...`. |
| Form says "not connected" | Do the Formspree steps above and restart the server. |
| Changes to `.env` ignored | Restart `npm run dev`. |

## 10. Prepare for deployment
```
npm run build
```
This creates a `dist/` folder, the finished website. Test it with `npm run preview`. Free hosts that work well: **Netlify**, **Vercel**, **Cloudflare Pages** (drag-and-drop the `dist` folder on Netlify, or connect a GitHub repo and set build command `npm run build`, output folder `dist`).
When deploying, add `VITE_FORM_ENDPOINT` in the host's "Environment variables" settings. Before launching, replace sample projects, update `<title>` and meta description in `index.html` if you like, and add your real domain as the Open Graph image URL.
